/* global QRCode */
QRCode.toSJIS = require('./to-sjis')
